import acsse.csc03a3.gui.Pane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub

		//Pane root = new Pane();
		Parent root = FXMLLoader.load(getClass().getResource("/acsse/csc03a3/gui/Home.fxml"));
		//String css = this.getClass().getResource("/acsse/csc03a3/gui/resources/style.css").toExternalForm();
		Scene scene = new Scene(root);
		//scene.getStylesheets().add(css);
		primaryStage.setScene(scene);
		primaryStage.setTitle("UJ SRC Voting Program");
		primaryStage.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
