package acsse.csc03a3.data_structure;

public interface Entry<K, V> {
	K getKey();
	V getValue();

	
}
