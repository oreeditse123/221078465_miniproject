package acsse.csc03a3.data_structure;

public interface List<T> {
	/**
	 * A method for returning the size of the list
	 * @return
	 */
	int size();
	
	/**
	 * A method for checking if the list is empty
	 */
	boolean isEmpty();
	
	/**
	 * A method that returns, but does not remove, the element at index i
	 */
	T get(int i);
	
	/**
	 * A method that replaces the element at index i with "element", and returns the the replaced element
	 */
	T set(int i, T element);
	
	/**
	 * A method that adds an element "element" at index i, shifting all the subsequent elements to the right
	 */
	void add(int i, T element);
	
	/**
	 * A method for removing an element at index i, then returns the removed element, shifting all subsequent elements to the left
	 */
	T remove(int i);
}
