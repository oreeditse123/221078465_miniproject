package acsse.csc03a3.data_structure;

public interface IMap<K, V> {
	int size();
	boolean isEmpty();
	V get(K key);
	V put(K key, V Value);
	V remove(K key);
	Iterable<K> keySet();
	Iterable<V> values();
	Iterable<Entry<K, V>> entrySet();
}
