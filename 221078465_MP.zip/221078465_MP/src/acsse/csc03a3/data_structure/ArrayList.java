package acsse.csc03a3.data_structure;

public class ArrayList<T> implements List<T> {

	private T[] data;
	private int size = 0;
	public static final int CAPACITY = 16;
	
	public ArrayList() {
		this(CAPACITY);
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList(int capacity) {
		this.data = (T[]) new Object[capacity];
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (size == 0);
	}

	@Override
	public T get(int i) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size);
		return this.data[i];
	}

	@Override
	public T set(int i, T element) throws IndexOutOfBoundsException {
		checkIndex(i, size);
		//create a variable to hold the element to be replaced
		T oldElement = data[i];
		//replace the element at index i
		data[i] = element;
		//return the replaced element
		return oldElement;
	}

	@Override
	public void add(int i, T element) throws IndexOutOfBoundsException, IllegalStateException {
		// TODO Auto-generated method stub
		checkIndex(i, size + 1);
		if(size == data.length)
			throw new IllegalStateException("Array is full");
		//start by moving the last element in the array to the right
		for(int k = size - 1; k >= i; k--) {
			data[k + 1] = data[k];
		}
		//Once all the element has been moved - then add element
		data[i] = element;
		//Increment size
		size++;
	}

	@Override
	public T remove(int i) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size);
		T removeElement = data[i];
		for(int k = i; k < size -1; k++) {
			data[k] = data[k + 1];
		}
		
		data[size - 1] = null;
		size--;
		return removeElement;
	}
	
	protected void checkIndex(int i, int n) throws IndexOutOfBoundsException {
		if(i < 0 || i > n) {
			throw new ArrayIndexOutOfBoundsException("Illegal Index:" + i);
		}
	}

}
