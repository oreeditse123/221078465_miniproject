package acsse.csc03a3.data_structure;

public class Node<T> {
	private T element;
	private Node<T> next;
	private Node<T> prev;
	
	public Node() {
		
	}
	
	public Node(Node<T> prev, Node<T> next, T element) {
		this.element = element;
		this.prev = prev;
		this.next = next;
	}
	
	
	T getElement() {
		return this.element;
	}
	
	Node<T> getPrev(){
		return this.prev;
	}
	
	Node<T> getNext(){
		return this.next;
	}
	
	public void setElement(T element) {
		this.element = element;
	}
	
	public void setPrev(Node<T> prev) {
		this.prev = prev;
	}
	
	public void setNext(Node<T> next) {
		this.next = next;
	}

	
}









