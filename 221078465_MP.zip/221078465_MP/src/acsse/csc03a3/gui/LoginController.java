package acsse.csc03a3.gui;

import java.io.IOException;


import acsse.csc03a3.client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginController extends Controller{
	@FXML
	Button btnLoginID;
	@FXML
	TextField name, surname, email, phone, age;
	@FXML
	PasswordField password;

	RegisterController rc = new RegisterController();

	public void btnLogin(ActionEvent event) throws IOException {
		btnLoginID.setOnAction(e -> {
			User user = rc.storeUserInfo();
			String username = user.getEmail();
			String password = user.getPassword();
			
			int id = user.verifyUser(username, password);
			if(id != -1) {
				try {
					System.out.println(password);
					switchScene("Home.fxml", event);
				} catch (IOException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			}else {
				Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Information Dialog");
		        alert.setHeaderText(null);
		        alert.setContentText("Invalid username or password ");

		        // Show the alert
		        alert.showAndWait();			}
		});
	}
	@FXML
	public void home(ActionEvent event) throws IOException {
		switchScene("Home.fxml", event);
	}
	@FXML
	public void login(ActionEvent event) throws IOException {
		
		switchScene("Login.fxml", event);
	}
	@FXML
	public void register(ActionEvent event) throws IOException {
		switchScene("Register.fxml", event);
	}
	@FXML
	public void about(ActionEvent event) throws IOException {
		switchScene("About.fxml", event);
	}
	@FXML
	public void vote(ActionEvent event) throws IOException {
		switchScene("Vote.fxml", event);
	}
	@FXML
	public void profile(ActionEvent event) throws IOException {
		switchScene("Profile.fxml", event);
	}
}
