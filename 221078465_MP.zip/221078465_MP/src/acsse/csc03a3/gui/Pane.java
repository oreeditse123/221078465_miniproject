package acsse.csc03a3.gui;

import java.io.BufferedReader;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import acsse.csc03a3.client.User;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Pane extends GridPane {
	
	private Stage stage = null;
	private Scene scene1 = null;
	private Scene scene2 = null;
	
	
	private Label lblName = null;
	private Label lblSurname = null;
	private Label lblEmail = null;
	private Label lblPassword = null;
	private Label lblPhone = null;

	private TextField txtName = null;
	private TextField txtSurname = null;
	private TextField txtEmail = null;
	private PasswordField password;
	private TextField txtPhone = null;
	private TextField txtDOP;
	private Button btnLogin = null;
	private Button btnRegister = null;
	
	//SceneController controller;
	
	private User user;	
	
	private PrintWriter writer = null;
	private BufferedReader reader = null;
	
	String userName;
	String userSurname;
	String userEmail;
	String userPassword;
	String userPhone;
	String userDOP;
	

	public Pane() {
		setUpGUI();
		
	}

	public void setUpGUI() {
		setVgap(10);
		setHgap(15);
		setAlignment(Pos.CENTER);
		
		btnRegister = new Button("Register");
		btnRegister.setOnAction(event -> {
			setScene(scene1);
			GridPane layout = new GridPane();
			
			lblName = new Label("Name:");
			lblSurname = new Label("Surname:");
			lblEmail = new Label("Email:");
			lblPassword = new Label("Password:");
			lblPhone = new Label("Phone number:");
			
			txtName = new TextField();
			txtSurname = new TextField();
			txtEmail = new TextField();
			password = new PasswordField();
			txtPhone = new TextField();
			Button Register = new Button("Register");
			
			
			layout.getChildren().add(lblName);
			layout.getChildren().add(txtName);
			layout.getChildren().add(lblSurname);
			layout.getChildren().add(txtSurname);
			layout.getChildren().add(lblEmail);
			layout.getChildren().add(txtEmail);
			layout.getChildren().add(lblPassword);
			layout.getChildren().add(password);
			layout.getChildren().add(lblPhone);
			layout.getChildren().add(txtPhone);
			layout.getChildren().add(Register);
			layout.getChildren().add(btnLogin);
			
			this.getChildren().add(layout);
			scene1 = new Scene(layout, 500, 570);
		});
		
		btnLogin = new Button("Login");
		btnRegister.setOnAction(event -> {
			setScene(scene1);
			GridPane layout2 = new GridPane();
			layout2.getChildren().add(btnRegister);
			scene1 = new Scene(layout2, 500, 570);
		});
		
		add(btnRegister, 0, 0);
		add(btnLogin, 0, 1);
		
		//this.getChildren().add(btnRegister);
	}
	
	public void setUpRegistrationGUI() {
		
	}
	
	public void setScene(Scene scene) {
		this.scene1 = scene;
	}
	
	private int validate(String username) {
		StringTokenizer tokenizer = new StringTokenizer(username);
		String email = tokenizer.nextToken();
		System.out.println(email);
		if(email.equals(this.txtEmail.getText())) {
			return 0;
		}
		else {
			return -1;
		}
	}

	private String writeToFile() {

		userName = txtName.getText();
		userSurname = txtSurname.getText();
		userEmail = txtEmail.getText();
		userPassword = password.getText();
		userPhone = txtPhone.getText();
		userDOP = txtDOP.getText();

		if(validate(userName) == 0) {
			try {

				BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true));
				writer.write(userName + "\n");
				writer.write(userSurname+ "\n");
				writer.write(userEmail+ "\n");
				writer.write(userPassword+ "\n");
				writer.write(userPhone+ "\n");
				writer.write(userDOP+ "\n");
				writer.write("\n");

				System.out.println("Successfully added user to file!!!");


			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				writer.close();
			}

			return userEmail;
		}
		else {

			return "User Exists!";
		}

	}

	public User getUerInfo(User user) {

		userName = txtName.getText();
		userSurname = txtSurname.getText();
		userEmail = txtEmail.getText();
		userPassword = password.getText();
		userPhone = txtPhone.getText();
		userDOP = txtDOP.getText();

		user.setName(userName);
		user.setSurname(userSurname);
		user.setEmail(userEmail);
		user.setPassword(userPassword);
		user.setPhone(userPhone);
		user.setDOP(userDOP);
		return null;
		//return new User(userID, userName, userSurname, userEmail, userPassword, userPhone, userDOP);
	}



}



