package acsse.csc03a3.gui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public abstract class Controller {
	protected Parent root;
	protected Stage stage;
	protected Scene scene;
	
	public Controller() {
		
	}
	
	public Controller(Scene scene, Stage stage) {
		this.scene = scene;
		this.stage = stage;
	}
	
	
	protected void switchScene(String fxmlFile, ActionEvent event) throws IOException{
		root = FXMLLoader.load(getClass().getResource(fxmlFile));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public Stage getStage() {
		return this.stage;
	}
	public Scene getScene() {
		return this.scene;
	}
	
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	
	public void setScene(Scene scene) {
		this.scene = scene;
	}
}



