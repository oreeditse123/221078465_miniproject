package acsse.csc03a3.gui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;

public class VoteController extends Controller {
//	@FXML
//	private Hyperlink link;
//
//	@FXML
//	public void switchScene(ActionEvent event) {
//		if(link.isPressed()) {
//			String page = link.getText();
//			System.out.println(page);
//			try {
//				switch(page) {
//				case "Home":
//					switchScene(page+".fxml", event);
//					break;
//				case "Login":
//					switchScene(page+".fxml", event);
//					break;
//				case "Register":
//					switchScene(page+".fxml", event);
//					break;
//				case "About":
//					switchScene(page+".fxml", event);
//					break;
//				case "Vote":
//					switchScene(page+".fxml", event);
//					break;
//				case "Profile":
//					switchScene(page+".fxml", event);
//					break;
//				}
//			}catch(IOException ex) {
//				ex.printStackTrace();
//			}
//		}
//	}
	
	
	@FXML
	public void home(ActionEvent event) throws IOException {
		switchScene("Home.fxml", event);
	}
	@FXML
	public void login(ActionEvent event) throws IOException {
		switchScene("Login.fxml", event);
	}
	@FXML
	public void register(ActionEvent event) throws IOException {
		switchScene("Register.fxml", event);
	}
	@FXML
	public void about(ActionEvent event) throws IOException {
		switchScene("About.fxml", event);
	}
	@FXML
	public void vote(ActionEvent event) throws IOException {
		switchScene("Vote.fxml", event);
	}
	@FXML
	public void profile(ActionEvent event) throws IOException {
		switchScene("Profile.fxml", event);
	}
	
}
