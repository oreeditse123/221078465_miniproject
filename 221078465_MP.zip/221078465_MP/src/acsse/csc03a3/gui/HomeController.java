package acsse.csc03a3.gui;

import java.io.IOException;

import javax.swing.event.HyperlinkListener;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.stage.Stage;

public class HomeController extends Controller {

	public HomeController() {
	}
	//String css = this.getClass().getResource("/acsse/csc03a3/gui/resources/styles.css").toExternalForm();
	//Scene scene1 = new Scene(root);

	@FXML
	public void home(ActionEvent event) throws IOException {
		switchScene("Home.fxml", event);
	}
	@FXML
	public void login(ActionEvent event) throws IOException {
		switchScene("Login.fxml", event);
	}
	@FXML
	public void register(ActionEvent event) throws IOException {
		switchScene("Register.fxml", event);
	}
	@FXML
	public void about(ActionEvent event) throws IOException {
		switchScene("About.fxml", event);
	}
	@FXML
	public void vote(ActionEvent event) throws IOException {
		switchScene("Vote.fxml", event);
	}
	@FXML
	public void profile(ActionEvent event) throws IOException {
		switchScene("Profile.fxml", event);
	}
}
