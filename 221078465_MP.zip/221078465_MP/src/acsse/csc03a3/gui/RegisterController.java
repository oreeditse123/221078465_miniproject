package acsse.csc03a3.gui;

import java.io.IOException;


import acsse.csc03a3.client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterController extends Controller{
	
	@FXML
	Button btnRegisterID;
	@FXML
	TextField txtName, txtSurname, txtEmail, txtPhone, txtAge;
	@FXML
	PasswordField txtPassword;

	int id = 0;
	
	User user;
//	private Hyperlink link;
	
	
	public RegisterController() {

	}
	
	public User storeUserInfo() {
		String name = txtName.getText();
		String surname = txtSurname.getText();
		String email = txtEmail.getText();
		String password = txtPassword.getText();
		String phone = txtPhone.getText();
		int age = Integer.parseInt(txtAge.getText());
		//user = new User(name, surname, email, password, phone, age);
		
		return new User(name, surname, email, password, phone, age);
	}
	
	public void btnRegister(ActionEvent event) throws IOException {
		btnRegisterID.setOnAction(e -> {
			User user = storeUserInfo();
			
			if(user.exists(user.getEmail()) == 0) {
				try {
					System.out.println(user.getName());
					switchScene("Login.fxml", event);
				} catch (IOException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			}else {
				Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Information Dialog");
		        alert.setHeaderText(null);
		        alert.setContentText("Seems like the user already exists!!!. Enter a different email");

		        // Show the alert
		        alert.showAndWait();			}
		});
	}
	
	@FXML
	public void home(ActionEvent event) throws IOException {
		switchScene("Home.fxml", event);
	}
	@FXML
	public void login(ActionEvent event) throws IOException {
		switchScene("Login.fxml", event);
	}
	@FXML
	public void register(ActionEvent event) throws IOException {
		switchScene("Register.fxml", event);
	}
	@FXML
	public void about(ActionEvent event) throws IOException {
		switchScene("About.fxml", event);
	}
	@FXML
	public void vote(ActionEvent event) throws IOException {
		switchScene("Vote.fxml", event);
	}
	@FXML
	public void profile(ActionEvent event) throws IOException {
		switchScene("Profile.fxml", event);
	}

}
