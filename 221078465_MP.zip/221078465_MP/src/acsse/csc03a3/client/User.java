package acsse.csc03a3.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class User {
	private static int ID = 0;
	
	private int userID;
	private String userName;
	private String userSurname;
	private String userEmail;
	private String userPassword;
	private String userPhone;
	private int userAge;
	private String DateOfApp;
	
	public User() {
		
	}
	
	public User(String name, String surname, String email, String password, String phone, int age) {
		userID = ++ID;
		this.userName = name;
		this.userSurname = surname;
		this.userEmail = email;
		this.userPassword = password;
		this.userPhone = phone;
		this.userAge = age;
		//this.DateOfApp = DOP;
		writeToFile();
	}
	
	public int exists(String userName) {
		if(!(userName.equals(this.userEmail))) {
			return -1;
		}
		else {
			return 0;
		}
	}
	
	public int verifyUser(String userName, String hashPassword) {
		try (BufferedReader reader = new BufferedReader(new FileReader("/data/users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String username = parts[3];
                String password = parts[4];
                int id = Integer.parseInt(parts[0]);
                if (userName.equals(username) && hashPassword.equals(password)) {
                    return id;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
	}
	
	public int getUserID() {
		return userID;
	}
	
	public String getName() {
		return userName;
	}
	
	public String getSurname() {
		return userSurname;
	}
	
	public String getEmail() {
		return userEmail;
	}
	
	public String getPassword() {
		return userPassword;
	}
	
	
	public String getPhone() {
		return userPhone;
	}
	
	public String getDOP() {
		return DateOfApp;
	}
	
	public int getAge() {
		return userAge;
	}
	

	
	public void setName(String name) {
		this.userName = name;
	}
	
	public void setSurname(String surname) {
		this.userSurname = surname;
	}
	
	public void setEmail(String email) {
		this.userEmail = email;
	}
	
	public void setPassword(String password) {
		this.userPassword = password;
	}
	
	public void setPhone(String phone) {
		this.userPhone = phone;
	}
	
	
	public void setDOP(String date) {
		this.DateOfApp = date;
	}
	
	public void setAge(int age) {
		this.userAge = age;
	}
	
	private void writeToFile() {
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("/data/users.txt", true))){
            writer.write(String.format("%d,%s,%s,%s,%s%n", userID, userName, userSurname, userEmail, userPassword, userPhone));

		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private void readFromFile() {
		try(BufferedReader reader = new BufferedReader(new FileReader("/data/users.txt"))){
			String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                userID = Math.max(userID, id);
            }
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
		
}