package acsse.csc03a3.client;

import java.util.List;

import acsse.csc03a3.Transaction;

public class Candidate<T> {
	private int candidateID;
	private String candidateName;
	private String description;
	private int votes;
	List<Transaction<T>> transactions;
	
	
	public Candidate() {
		
	}
	
	public Candidate(int id, String name, String description, int numVotes) {
		
	}
	
	public String getCandidateName() {
		return this.candidateName;
	}
	
	public int getID() {
		return this.candidateID;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public int getVoteCount() {
		return this.votes;
	}
	
	public void incrementVotes() {
		votes++;
	}
	
}








