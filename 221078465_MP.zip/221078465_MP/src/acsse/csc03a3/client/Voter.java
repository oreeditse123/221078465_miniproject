package acsse.csc03a3.client;

public class Voter extends User {
	private int voterID = 0;
	private String chooseCandidate;
	private int age = 0;
	
	public Voter(String id, String party, int age) {

		
	}
	
	public Voter(String name, String surname, String vote, int age) {
		
	}
	
	private void placeVote() {
		
	}
	
	private void changeVote() {
		
	}
	
	private boolean isEligible() {
		return false;
	}
}
