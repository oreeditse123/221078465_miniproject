package acsse.csc03a3.client;

import acsse.csc03a3.Block;
import acsse.csc03a3.Transaction;
import acsse.csc03a3.data_structure.ArrayList;
import acsse.csc03a3.data_structure.Entry;
import acsse.csc03a3.data_structure.UnsortedTableMap;

public class VotingSystem<K, V> {
	private Voter voter;
	private Candidate candidate;
	private Transaction<K> transactions;

	
	UnsortedTableMap<K, V> candidates;
	ArrayList<Voter> votes;
	
	public VotingSystem() {
		candidates = new UnsortedTableMap<>();
		votes = new ArrayList<>();
		
	}
	
	public void addCandidate(int id) {
		if(!candidates.isEmpty()) {
			
		}
	}
	
	private void calculateVotes(int count) {
		
	}
	
	private void determineWinner(int count) {
		
	}
	
	private void displayWinner() {
		
	}
}
