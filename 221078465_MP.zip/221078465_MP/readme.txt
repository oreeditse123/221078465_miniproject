Link to YouTube video: "https://youtu.be/3-nKJfUVGiY"
Link to Dropbox: "https://www.dropbox.com/scl/fo/mwpfkt36v5d3ebgva8oe8/AJWG9Wvvx39gFI4wSYSSwL4?rlkey=bp4bku2zihk53r18c7t21cvj9&st=8uxuk0zj&dl=0"
Link to GitHub: "https://github.com/oreeditse123/221078465_miniproject.git"